Course Name: CS373
Unique: 91055

First Name: Ryan
Last Name: Kluck
EID: rrk357
E-mail: rk122988@utexas.edu
Estimated number of hours: 6
Actual number of hours: 8

Partner First Name:
Partner Last Name:
Partner EID:
Partner E-mail:
Partner Estimated number of hours:
Partner Actual number of hours:


