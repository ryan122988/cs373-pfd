#!/usr/bin/env python

# -------------------------------
# projects/collatz/TestCollatz.py
# Copyright (C) 2011
# Glenn P. Downing
# -------------------------------

"""
To test the program:
% python TestPFD.py > TestPFD.out
% chmod ugo+x TestPFD.py
% TestPFD.py > TestPFD.out
"""

# -------
# imports
# -------

import StringIO
import unittest

from PFD import sort, find_no_preds, generate_successors_list, is_a_successor, get_successors, noPreds_sort, update, generate_solution
# collatz_eval, collatz_print, collatz_solve, collatz_cycle_length

# -----------
# TestCollatz
# -----------

class TestPFD (unittest.TestCase) :

    # ------
    # sort
    # ------
    def test_sort1 (self) :
        a = [2, 2, 5, 6]
        b = [1 , 1, 5]
        c = [3, 1, 1]
        d = [4, 2, 2, 3]
        rules = []
        numVerticies = 5
        numRules = 4
        rules.append(a)
        rules.append(b)
        rules.append(c)
        rules.append(d)
        e = sort(rules, numVerticies, numRules)
        self.assert_(e[0][0] == -1)
        self.assert_(e[1][0] == 4)
        self.assert_(e[2][0] == 3)
        self.assert_(e[3][0] == 2)
        self.assert_(e[4][0] == 1)
        print "passed sort test 1"

    def test_sort2 (self) :
        a = [2, 2, 5, 6]
        c = [3, 1, 1]
        d = [4, 2, 2, 3]
        rules = []
        numVerticies = 4
        numRules = 3
        rules.append(a)
        rules.append(c)
        rules.append(d)
        e = sort(rules, numVerticies, numRules)
        self.assert_(e[0][0] == 4)
        self.assert_(e[1][0] == 3)
        self.assert_(e[2][0] == 2)
        self.assert_(e[3][0] == -1)
        print "passed sort test 2"

    def test_sort3 (self) :
        a = [2, 2, 5, 6]
        b = [1 , 1, 5]
        c = [3, 1, 1]
        d = [4, 2, 2, 3]
        rules = []
        numVerticies = 7
        numRules = 4
        rules.append(a)
        rules.append(b)
        rules.append(c)
        rules.append(d)
        e = sort(rules, numVerticies, numRules)
        self.assert_(e[0][0] == -1)
        self.assert_(e[1][0] == -1)
        self.assert_(e[2][0] == -1)
        self.assert_(e[3][0] == 4)
        self.assert_(e[4][0] == 3)
        self.assert_(e[5][0] == 2)
        self.assert_(e[6][0] == 1)
        print "passed sort test 3"



    # ---------
    # find_no_preds
    # ---------
    def test_find_no_preds1 (self) :
        c = [2, 2, 5, 6]
        d = [1 , 1, 5]
        b = [3, 1, 1]
        a = [4, 2, 2, 3]
        extra = [-1]
        rules = []
        numVerticies = 7
        rules.append(extra)
        rules.append(extra)
        rules.append(extra)
        rules.append(a)
        rules.append(b)
        rules.append(c)
        rules.append(d)
        e = find_no_preds(rules, numVerticies)
        self.assert_(e[0] == 7)
        self.assert_(e[1] == 6)
        self.assert_(e[2] == 5)
        print "passed find_no_preds test 1"

    def test_find_no_preds2 (self) :
        c = [2, 2, 5, 6]
        d = [1 , 1, 5]
        #b = [3, 1, 1]
        b = [-1]
        a = [4, 2, 2, 3]
        extra = [-1]
        rules = []
        numVerticies = 8
        rules.append(extra)
        rules.append(extra)
        rules.append(extra)
        rules.append(extra)
        rules.append(a)
        rules.append(b)
        rules.append(c)
        rules.append(d)
        e = find_no_preds(rules, numVerticies)
        self.assert_(e[0] == 8)
        self.assert_(e[1] == 7)
        self.assert_(e[2] == 6)
        self.assert_(e[3] == 5)
        self.assert_(e[4] == 3)
        print "passed find_no_preds test 2"

    def test_find_no_preds3 (self) :
        extra = [-1]
        rules = []
        numVerticies = 3
        rules.append(extra)
        rules.append(extra)
        rules.append(extra)
        e = find_no_preds(rules, numVerticies)
        self.assert_(e[0] == 3)
        self.assert_(e[1] == 2)
        self.assert_(e[2] == 1)
        print "passed find_no_preds test 3"


    # -----------
    # generate_successors_list
    # -----------
    def test_generate_successors_list1 (self) :
        c = [2, 1, 6]
        d = [1 , 1, 5]
        b = [3, 1, 1]
        a = [4, 2, 2, 3]
        extra = [-1]
        rules = []
        rules.append(extra)
        rules.append(extra)
        rules.append(extra)
        rules.append(a)
        rules.append(b)
        rules.append(c)
        rules.append(d)
        e = generate_successors_list(rules)
        self.assert_(e[0][0] == -1)
        self.assert_(e[1][0] == 2)
        self.assert_(e[2][0] == 1)
        self.assert_(e[3][0] == -1)
        self.assert_(e[4][0] == 4)
        self.assert_(e[5][0] == 4)
        self.assert_(e[6][0] == 3)
        print "passed generate_successors_list test 1"


    def test_generate_successors_list2 (self) :
        c = [2, 1, 4]
        d = [1 , 1, 5]
        b = [3, 1, 1]
        a = [4, 2, 2, 3]
        extra = [-1]
        rules = []
        rules.append(extra)
        rules.append(a)
        rules.append(b)
        rules.append(c)
        rules.append(d)
        e = generate_successors_list(rules)
        self.assert_(e[0][0] == 1)
        self.assert_(e[1][0] == 2)
        self.assert_(e[2][0] == 4)
        self.assert_(e[3][0] == 4)
        self.assert_(e[4][0] == 3)
        print "passed generate_successors_list test 2"


    def test_generate_successors_list3 (self) :
        a = [1 , 1, 2]
        extra = [-1]
        rules = []
        rules.append(extra)
        rules.append(a)
        e = generate_successors_list(rules)
        print e[0][0]
        self.assert_(e[0][0] == 1)
        self.assert_(e[1][0] == -1)
        print "passed generate_successors_list test 3"


    # ----------
    # is_a_successor
    #
    def test_is_a_successor1 (self) :
        c = [2, 1, 6]
        e = is_a_successor(c, 6)
        self.assert_(e == True)
        print "passed is_a_successor test 1"


    def test_is_a_successor2 (self) :
        a = [4, 2, 2, 3]
        e = is_a_successor(a, 3)
        self.assert_(e == True)
        print "passed generate_successors_list test 2"

    def test_is_a_successor3 (self) :
        b = [3, 1, 1]
        e = is_a_successor(b, 2)
        self.assert_(e == False)
        print "passed generate_successors_list test 3"


    # ------------
    # get_successors
    # ------------

    def test_get_successors1 (self) :
        c = [2, 1, 6]
        d = [1 , 1, 5]
        b = [3, 1, 1]
        a = [4, 2, 2, 3]
        extra = [-1]
        rules = []
        numVerticies = 7
        rules.append(extra)
        rules.append(extra)
        rules.append(extra)
        rules.append(a)
        rules.append(b)
        rules.append(c)
        rules.append(d)
        e = get_successors(rules, 2, 5)
        self.assert_(e[0] == 4)
        print "passed get_successors test 1"

    def test_get_successors2 (self) :
        c = [2, 1, 6]
        d = [1 , 1, 5]
        b = [3, 1, 1]
        a = [4, 2, 2, 3]
        extra = [-1]
        rules = []
        numVerticies = 7
        rules.append(extra)
        rules.append(extra)
        rules.append(extra)
        rules.append(a)
        rules.append(b)
        rules.append(c)
        rules.append(d)
        e = get_successors(rules, 5, 2)
        self.assert_(e[0] == 1)
        print "passed get_successors test 2"

    def test_get_successors3 (self) :
        c = [2, 1, 6]
        d = [1 , 1, 5]
        b = [3, 1, 1]
        a = [4, 2, 2, 3]
        extra = [-1]
        rules = []
        numVerticies = 7
        rules.append(extra)
        rules.append(extra)
        rules.append(extra)
        rules.append(a)
        rules.append(b)
        rules.append(c)
        rules.append(d)
        e = get_successors(rules, 7, 0)
        self.assert_(e[0] == -1)
        print "passed get_successors test 3"


    # -----------
    # noPreds_sort
    # -----------
    def test_noPreds_sort1 (self) :
        e = [5, 4, 3, 2, 1, 6]
        noPreds_sort(e)
        self.assert_(e[0] == 6)
        self.assert_(e[1] == 5)
        self.assert_(e[2] == 4)
        self.assert_(e[3] == 3)
        self.assert_(e[4] == 2)
        self.assert_(e[5] == 1)
        print "passeed noPreds_sort test 1"

    def test_noPreds_sort2 (self) :
        e = [1, 2]
        noPreds_sort(e)
        self.assert_(e[0] == 2)
        self.assert_(e[1] == 1)
        print "passeed noPreds_sort test 2"

    def test_noPreds_sort3 (self) :
        e = [6, 5, 4, 2, 1, 3]
        noPreds_sort(e)
        self.assert_(e[0] == 6)
        self.assert_(e[1] == 5)
        self.assert_(e[2] == 4)
        self.assert_(e[3] == 3)
        self.assert_(e[4] == 2)
        self.assert_(e[5] == 1)
        print "passeed noPreds_sort test 3"


    # ------------
    # update
    # ------------
 
    def test_update1 (self) :
        noPreds = [7, 6, 5]
        c = [2, 1, 6]
        d = [1 , 1, 5]
        b = [3, 1, 1]
        a = [4, 2, 2, 3]
        extra = [-1]
        rules = []
        numVerticies = 7
        rules.append(extra)
        rules.append(extra)
        rules.append(extra)
        rules.append(a)
        rules.append(b)
        rules.append(c)
        rules.append(d)
        s1 = [3]
        s2 = [4]
        s3 = [4]
        s4 = [-1]
        s5 = [1]
        s6 = [2]
        s7 = [-1]
        sList = []
        sList.append(s7)
        sList.append(s6)
        sList.append(s5)
        sList.append(s4)
        sList.append(s3)
        sList.append(s2)
        sList.append(s1)
        update(5, noPreds, rules, sList)
        self.assert_(len(noPreds) == 3)
        self.assert_(noPreds[0] == 7)
        self.assert_(noPreds[1] == 6)
        self.assert_(noPreds[2] == 1)
        print "passed update test 1"


    def test_update2 (self) :
        noPreds = [7, 6]
        c = [2, 1, 6]
        d = [1 , 1, 5]
        b = [3, 1, 1]
        a = [4, 2, 2, 3]
        e = [5, 2, 2]
        extra = [-1]
        rules = []
        numVerticies = 7
        rules.append(extra)
        rules.append(extra)
        rules.append(e)
        rules.append(a)
        rules.append(b)
        rules.append(c)
        rules.append(d)
        s1 = [3]
        s2 = [4, 2]
        s3 = [4]
        s4 = [-1]
        s5 = [1]
        s6 = [2]
        s7 = [-1]
        sList = []
        sList.append(s7)
        sList.append(s6)
        sList.append(s5)
        sList.append(s4)
        sList.append(s3)
        sList.append(s2)
        sList.append(s1)
        update(6, noPreds, rules, sList)
        self.assert_(len(noPreds) == 2)
        self.assert_(noPreds[0] == 7)
        self.assert_(noPreds[1] == 2)
        print "passed update test 2"

    def test_update3 (self) :
        noPreds = [7]
        c = [2, 1, 6]
        d = [1 , 1, 5]
        b = [3, 1, 1]
        a = [4, 2, 2, 3]
        e = [5, 2, 2]
        f = [6, 1, 7]
        extra = [-1]
        rules = []
        numVerticies = 7
        rules.append(extra)
        rules.append(f)
        rules.append(e)
        rules.append(a)
        rules.append(b)
        rules.append(c)
        rules.append(d)
        s1 = [3]
        s2 = [4]
        s3 = [4]
        s4 = [-1]
        s5 = [1]
        s6 = [2]
        s7 = [6]
        sList = []
        sList.append(s7)
        sList.append(s6)
        sList.append(s5)
        sList.append(s4)
        sList.append(s3)
        sList.append(s2)
        sList.append(s1)
        update(7, noPreds, rules, sList)
        self.assert_(len(noPreds) == 1)
        self.assert_(noPreds[0] == 6)
        print "passed update test 3"



    # -----------
    # generate_solution
    # -----------
  
    def test_generate_solution1 (self) :
        a = [1, 1, 2]
        b = [2, 2, 3, 4]
        c = [5, 1, 3]
        empty = [-1]
        rules = []
        rules.append(c)
        rules.append(empty)
        rules.append(empty)
        rules.append(b)
        rules.append(a)
        noPreds = [4, 3]
        s1 = [-1]
        s2 = [1]
        s3 = [5, 2]
        s4 = [2]
        s5 = [-1]
        sList = []
        sList.append(s5)
        sList.append(s4)
        sList.append(s3)
        sList.append(s2)
        sList.append(s1)
        out = generate_solution(noPreds, rules, sList)
        self.assert_(out == "3 4 2 1 5")
        print "passed generate_solution test 1"

    def test_generate_solution2 (self) :
        a = [1, 1, 2]
        b = [2, 1, 3]
        c = [3, 1, 4]
        d = [4, 1, 5]
        empty = [-1]
        rules = []
        rules.append(empty)
        rules.append(d)
        rules.append(c)
        rules.append(b)
        rules.append(a)
        noPreds = [5]
        s1 = [-1]
        s2 = [1]
        s3 = [2]
        s4 = [3]
        s5 = [4]
        sList = []
        sList.append(s5)
        sList.append(s4)
        sList.append(s3)
        sList.append(s2)
        sList.append(s1)
        out = generate_solution(noPreds, rules, sList)
        self.assert_(out == "5 4 3 2 1")
        print "passed generate_solution test 2"

    def test_generate_solution3 (self) :
        a = [1, 1, 4]
        b = [2, 1, 1]
        c = [3, 1, 2]
        d = [4, 1, 5]
        empty = [-1]
        rules = []
        rules.append(empty)
        rules.append(d)
        rules.append(c)
        rules.append(b)
        rules.append(a)
        noPreds = [5]
        s1 = [2]
        s2 = [3]
        s3 = [-1]
        s4 = [1]
        s5 = [4]
        sList = []
        sList.append(s5)
        sList.append(s4)
        sList.append(s3)
        sList.append(s2)
        sList.append(s1)
        out = generate_solution(noPreds, rules, sList)
        self.assert_(out == "5 4 1 2 3")
        print "passed generate_solution test 3"



"""   
# ----
    # read
    # ----

    def test_read (self) :
        r = StringIO.StringIO("1 10\n")
        a = [0, 0]
        b = collatz_read(r, a)
        self.assert_(b == True)
        self.assert_(a[0] == 1)
        self.assert_(a[1] == 10)
# ----
# eval
# ----

    def test_eval_1 (self) :
        v = collatz_eval(1, 10)
        self.assert_(v == 20)

    def test_eval_2 (self) :
        v = collatz_eval(100, 200)
        self.assert_(v == 125)

    def test_eval_3 (self) :
        v = collatz_eval(201, 210)
        self.assert_(v == 89)

    def test_eval_4 (self) :
        v = collatz_eval(900, 1000)
        self.assert_(v == 174)


    #added by me
    def test_eval_5 (self) :
        v = collatz_eval(1601, 1709)
        self.assert_(v == 180)

    def test_eval_6 (self) :
        v = collatz_eval(70601, 71054)
        self.assert_(v == 312)

    def test_eval_7 (self) :
        v = collatz_eval(189001, 190046)
        self.assert_(v == 360)


    # -----
    # cycle Length
    # -----
    collatz_cycle_length

    def test_cycle_1 (self) :
        v = collatz_cycle_length(100)
        self.assert_(v == 26)

    def test_cycle_2 (self) :
        v = collatz_cycle_length(200)
        self.assert_(v == 27)

    def test_cycle_3 (self) :
        v = collatz_cycle_length(1000)
        self.assert_(v == 112)
    # -----
    # print
    # -----

    def test_print (self) :
        w = StringIO.StringIO()
        collatz_print(w, 1, 10, 20)
        self.assert_(w.getvalue() == "1 10 20\n")

    # -----
    # solve
    # -----

    def test_solve (self) :
        r = StringIO.StringIO("1 10\n100 200\n201 210\n900 1000\n")
        w = StringIO.StringIO()
        collatz_solve(r, w)
        self.assert_(w.getvalue() == "1 10 20\n100 200 125\n201 210 89\n900 1000 174\n")
"""

# ----
# main
# ----

print "TestPFD.py"
unittest.main()
print "Done."
